@include('dashboard.components.right-nav')
<?php do_action('footer'); ?>
<?php do_action('init_footer'); ?>
<?php do_action('init_dashboard_footer'); ?>
<script src="{{asset('js/option.js')}}"></script>
<script src="{{asset('js/dashboard.js')}}"></script>
</body>
</html>
